/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define CarrierWaveFreq 27000
#define PwmAccount (216000000 / CarrierWaveFreq)

#define NUM_OF_COIL 3

#define USART3_RX_MAX_LEGTH 200
#define USART3_RX_LEGTH (NUM_OF_COIL * 12 + 2)

#define PI  3.141592653

#ifdef __GNUC__
    #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
    #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

#define DEBUG
#ifdef DEBUG
    #define debug(fmt, ...) printf("%s %s%s %s %d:"fmt, __FILE__,?__FUNCTION__, __DATE__, __TIME__, __LINE__, ##__VA_ARGS__)
#else
    #define debug(fmt, ...)
#endif
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint8_t TempChar[1];
volatile uint8_t USART3_RX_BUF[USART3_RX_MAX_LEGTH] = { 0 };
volatile uint8_t USART3_RX_COUNT = 0;
volatile uint8_t USART3_RX_FLAG = 0;

uint8_t Selector[NUM_OF_COIL] = { 0 };
uint8_t NO[NUM_OF_COIL] = { 0 };
uint8_t PWM_State[5] = {0, 0, 1, 1, 1};
float DC_Scale[5] = { 0 };
float AC_Scale[5] = { 0 };
uint16_t ModulationWaveFreq = 50;   

float Tim_Buf[CarrierWaveFreq] = {0};
uint16_t SineWaveCount = CarrierWaveFreq;
volatile uint16_t Tim1_Ptr = 0;
volatile uint16_t Tim8_Ptr = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
uint8_t Limit8(uint8_t x, uint8_t l, uint8_t h) { if (x < l) return l; else if (x > h) return h; else return x; }
int Limit(int x, int l, int h) { if (x < l) return l; else if (x > h) return h; else return x; }
float FLimit(float x, float l, float h) { if (x < l) return l; else if (x > h) return h; else return x; }
void Control_Selectors(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
PUTCHAR_PROTOTYPE
{
    HAL_UART_Transmit(&huart3, (uint8_t*)&ch, 1, 0xFFFF);
    return ch;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* USER CODE BEGIN 1 */

    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_TIM1_Init();
    MX_TIM8_Init();
    MX_USART3_UART_Init();
		


    /* USER CODE BEGIN 2 */
		//Generate sine wave data
		SineWaveCount = CarrierWaveFreq / ModulationWaveFreq;
    for (int k = 0; k < SineWaveCount; k++)
    {
				Tim_Buf[k] = PwmAccount / 2 * sin(2 * PI * (float)k / (float)SineWaveCount);
    }
    printf("[%d:%d] Sin Wave Generate Complete!\r\n", HAL_GetTick() / 1000, HAL_GetTick() % 1000);

    //Enable TIMER 1
    HAL_TIM_Base_Start_IT(&htim1);
		if(PWM_State[0])
		{
				HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
				HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
		}
		if(PWM_State[1])
		{
				HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
				HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
		}
		if(PWM_State[2])
		{
				HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);
				HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
		}

    //Enable TIMER 8
    HAL_TIM_Base_Start_IT(&htim8);
		if(PWM_State[3])
		{
				HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_1);
				HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);
		}
		if(PWM_State[4])
		{
				HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_3);
				HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_3);
		}

		//Enable TIMER 8
//		__HAL_UART_ENABLE_IT(&huart3, UART_IT_RXNE);
    HAL_UART_Receive_IT(&huart3, (uint8_t *)TempChar, 1);
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* USER CODE END WHILE */
//			printf("Hello world!:%d\r\n", USART3_RX_COUNT);
			if (USART3_RX_FLAG)
        {
						uint8_t PWM_State_copy[5] = {0, 0, 0, 0, 0};
						for (int i = 0; i < NUM_OF_COIL; i++)
						{
								Selector[i] = *(USART3_RX_BUF + i * 12);
								Selector[i] -= 1;
								Selector[i]  = Limit8(Selector[i], 0, 4);
								NO[i] = *(USART3_RX_BUF + i * 12 + 1);
								NO[i] -= 1;
								NO[i]  = Limit8(NO[i], 0, 7);
							
								PWM_State_copy[Selector[i]] = 1;
								DC_Scale[Selector[i]] = (float)(*(int32_t*)(USART3_RX_BUF  + i * 12 + 4 )) / 1000;
								AC_Scale[Selector[i]] = (float)(*(int32_t*)(USART3_RX_BUF  + i * 12 + 8 )) / 1000;
						}

						uint16_t ModulationWaveFreq_new = *(USART3_RX_BUF + NUM_OF_COIL * 12);						
						if (ModulationWaveFreq != ModulationWaveFreq_new)
						{
								ModulationWaveFreq = ModulationWaveFreq_new;
								
								SineWaveCount = CarrierWaveFreq / ModulationWaveFreq;
								for (int k = 0; k < SineWaveCount; k++)
								{
										Tim_Buf[k] = PwmAccount / 2 * sin(2 * PI * (float)k / (float)SineWaveCount);
								}
								printf("[%d:%d] Sin Wave %d Hz Generate Complete!\r\n", HAL_GetTick() / 1000, HAL_GetTick() % 1000, ModulationWaveFreq);
								
								Tim1_Ptr = 0;
								Tim8_Ptr = 0;
						}
						
						memcpy(PWM_State, PWM_State_copy, sizeof(PWM_State));
						
						printf("%d %d %d %d %d\r\n", PWM_State[0],  PWM_State[1], PWM_State[2], PWM_State[3], PWM_State[4]);
						
						Control_Selectors();

            USART3_RX_FLAG = 0;
        }

        /* USER CODE BEGIN 3 */
    }

    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

    /** Configure LSE Drive Capability
    */
    HAL_PWR_EnableBkUpAccess();
    /** Configure the main internal regulator output voltage
    */
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 8;
    RCC_OscInitStruct.PLL.PLLN = 432;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 4;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Activate the Over-Drive mode
    */
    if (HAL_PWREx_EnableOverDrive() != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                  | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK)
    {
        Error_Handler();
    }

    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USART3;
    PeriphClkInitStruct.Usart3ClockSelection = RCC_USART3CLKSOURCE_PCLK1;

    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */
void Control_Selectors()
{
    for (int i = 0; i < NUM_OF_COIL; i++)
    {
				switch (Selector[i])
				{
						case 0:
								HAL_GPIO_WritePin(P1_1_GPIO_Port, P1_1_Pin, NO[i] & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P1_2_GPIO_Port, P1_2_Pin, NO[i] >> 1 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P1_3_GPIO_Port, P1_3_Pin, NO[i] >> 2 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								break;

						case 1:
								HAL_GPIO_WritePin(P2_1_GPIO_Port, P2_1_Pin, NO[i] & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P2_2_GPIO_Port, P2_2_Pin, NO[i] >> 1 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P2_3_GPIO_Port, P2_3_Pin, NO[i] >> 2 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								break;

						case 2:
								HAL_GPIO_WritePin(P3_1_GPIO_Port, P3_1_Pin, NO[i] & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P3_2_GPIO_Port, P3_2_Pin, NO[i] >> 1 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P3_3_GPIO_Port, P3_3_Pin, NO[i] >> 2 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								break;

						case 3:
								HAL_GPIO_WritePin(P4_1_GPIO_Port, P4_1_Pin, NO[i] & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P4_2_GPIO_Port, P4_2_Pin, NO[i] >> 1 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P4_3_GPIO_Port, P4_3_Pin, NO[i] >> 2 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								break;

						case 4:
								HAL_GPIO_WritePin(P5_1_GPIO_Port, P5_1_Pin, NO[i] & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P5_2_GPIO_Port, P5_2_Pin, NO[i] >> 1 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								HAL_GPIO_WritePin(P5_3_GPIO_Port, P5_3_Pin, NO[i] >> 2 & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
								break;

						default:
								break;
				}
    }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{	
    /* Prevent unused argument(s) compilation warning */
    if (htim->Instance == htim1.Instance)
    {
        if (PWM_State[0] == 0)
        {
            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Stop(&htim1, TIM_CHANNEL_1);
        }
        else
        {
            HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
            
            uint16_t value = PwmAccount * (1 + DC_Scale[0]) / 2 + Tim_Buf[Tim1_Ptr] * AC_Scale[0];
            __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, (uint16_t)Limit(value, 0, PwmAccount));
        }

        if (PWM_State[1] == 0)
        {
            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_2);
            HAL_TIMEx_PWMN_Stop(&htim1, TIM_CHANNEL_2);
        }
        else
        {
            HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
            HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
            
            uint16_t value = PwmAccount * (1 + DC_Scale[1]) / 2 + Tim_Buf[Tim1_Ptr] * AC_Scale[1];
            __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, (uint16_t)Limit(value, 0, PwmAccount));
        }

        if (PWM_State[2] == 0)
        {
            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Stop(&htim1, TIM_CHANNEL_3);
        }
        else
        {
            HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);
            
            uint16_t value = PwmAccount * (1 + DC_Scale[2]) / 2 + Tim_Buf[Tim1_Ptr] * AC_Scale[2];
            __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, (uint16_t)Limit(value, 0, PwmAccount));
        }

        if (++Tim1_Ptr >= SineWaveCount) Tim1_Ptr = 0;
    }
    else if (htim->Instance == htim8.Instance)
    {
        if (PWM_State[3] == 0)
        {
            HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Stop(&htim8, TIM_CHANNEL_1);
        }
        else
        {			
            HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_1);
            
            uint16_t value = PwmAccount * (1 + DC_Scale[3]) / 2 + Tim_Buf[Tim1_Ptr] * AC_Scale[3];
            __HAL_TIM_SetCompare(&htim8, TIM_CHANNEL_1, (uint16_t)Limit(value, 0, PwmAccount));
        }

        if (PWM_State[4] == 0)
        {
            HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Stop(&htim8, TIM_CHANNEL_3);
        }
        else
        {					
						HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_3);
            
            uint16_t value = PwmAccount * (1 + DC_Scale[4]) / 2 + Tim_Buf[Tim1_Ptr] * AC_Scale[4];
            __HAL_TIM_SetCompare(&htim8, TIM_CHANNEL_3, (uint16_t)Limit(value, 0, PwmAccount));
        }

        if (++Tim8_Ptr >= SineWaveCount) Tim8_Ptr = 0;
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == huart3.Instance)
    {
        if (!USART3_RX_FLAG)
        {
            if('\n'!= TempChar[0] )
            {
                USART3_RX_BUF[USART3_RX_COUNT++] = TempChar[0];

                if (USART3_RX_COUNT >= USART3_RX_MAX_LEGTH) USART3_RX_COUNT = 0;
            }
            else if(USART3_RX_COUNT == USART3_RX_LEGTH + 1)
            {
                if('\r' == USART3_RX_BUF[USART3_RX_COUNT - 1])
                {                    
										USART3_RX_COUNT = 0;
                    USART3_RX_FLAG = 1;
                }
                else USART3_RX_COUNT = 0;
            }
            else
						{
								USART3_RX_COUNT = 0;
						}
        }
    }

    while(HAL_UART_Receive_IT(&huart3, (uint8_t *)TempChar, 1) != HAL_OK);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();

    while (1)
    {
    }

    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
    /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
