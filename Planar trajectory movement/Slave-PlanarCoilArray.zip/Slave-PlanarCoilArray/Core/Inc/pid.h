#ifndef _PID_H_
#define _PID_H_

typedef void (*_PID_FUNC)(float, float*, void*);

typedef struct{
	float Kp;
	float Ki;
	float Kd;
    float Kt;
	float CurrentValue;
    float LeastValue;
	float SetValue;
	float err;
	float errlast;
	float errlastlast;
	float out;
    float outlast;
    float threshold;
	float integral;
	float maximum;
	float minimum;
	_PID_FUNC *_PID_Count;
}PID_t;

void PID_Place(float currentvalue, float * OutPut, void *p);
void PID_PlaceKt(float currentvalue, float * OutPut, void *p);
void PID_Cascade(float currentvalue, float * OutPut, void *p);
void PID_Realize(float currentvalue, float * OutPut, void *p);
void PID_Init(PID_t *PID, float Kp, float Ki, float Kd, float Kt, float SetValue, float threshold, float maximum, float minimum, _PID_FUNC *_PID_Count);

#endif
