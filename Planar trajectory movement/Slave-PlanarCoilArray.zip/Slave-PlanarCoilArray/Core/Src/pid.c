#include "pid.h"
#include "main.h"

void PID_Place(float currentvalue, float * OutPut, void *p)
{
    PID_t *PID = p;
    PID->CurrentValue = currentvalue;
    PID->err = PID->SetValue - PID->CurrentValue;
    PID->integral += PID->err;
    PID->out = PID->Kp * PID->err + PID->Ki * PID->integral + PID->Kd * (PID->err - PID->errlast);

    PID->LeastValue = PID->CurrentValue;
    PID->errlast = PID->err;
    PID->errlastlast = PID->errlast;

    if (ABS(PID->out - PID->outlast) > PID->threshold)
    {
        if(PID->out > PID->outlast)
            PID->out = PID->outlast + PID->threshold;
        else
            PID->out = PID->outlast - PID->threshold;
    }

    if (PID->out >= PID->maximum)
        PID->out = PID->maximum;
    else if (PID->out <= PID->minimum)
        PID->out = PID->minimum;

    *OutPut = PID->out;
    PID->outlast = *OutPut;
}

void PID_PlaceKt(float currentvalue, float * OutPut, void *p)
{
    float Kp;
    PID_t *PID = p;
    PID->CurrentValue = currentvalue;
    PID->err = PID->SetValue - PID->CurrentValue;
    Kp = 0.01 * (PID->err * PID->err) / PID->Kt + PID->Kp;
    PID->out = Kp * PID->err + PID->Kd * (PID->err - PID->errlast);

    PID->LeastValue = PID->CurrentValue;
    PID->errlast = PID->err;
    PID->errlastlast = PID->errlast;

    if (ABS(PID->out - PID->outlast) > PID->threshold)
    {
        if(PID->out > PID->outlast)
            PID->out = PID->outlast + PID->threshold;
        else
            PID->out = PID->outlast - PID->threshold;
    }

    if (PID->out >= PID->maximum)
        PID->out = PID->maximum;
    else if (PID->out <= PID->minimum)
        PID->out = PID->minimum;

    *OutPut = PID->out;
    PID->outlast = *OutPut;
}

void PID_Cascade(float currentvalue, float * OutPut, void *p)
{
    float Increase;
    PID_t *PID = p;
    PID->CurrentValue = currentvalue;
    PID->err = PID->SetValue - PID->CurrentValue;
    Increase = -PID->Kp * (PID->CurrentValue - PID->LeastValue) + PID->Ki * PID->err + PID->Kd * (PID->err - 2 * PID->errlast + PID->errlastlast);
    PID->out = PID->outlast + Increase;

    PID->LeastValue = PID->CurrentValue;
    PID->errlast = PID->err;
    PID->errlastlast = PID->errlast;

    if (ABS(PID->out - PID->outlast) > PID->threshold)
    {
        if(PID->out > PID->outlast)
            PID->out = PID->outlast + PID->threshold;
        else
            PID->out = PID->outlast - PID->threshold;
    }

    if (PID->out >= PID->maximum)
        PID->out = PID->maximum;
    else if (PID->out <= PID->minimum)
        PID->out = PID->minimum;

    *OutPut = PID->out;
    PID->outlast = *OutPut;
}

void PID_Realize(float currentvalue, float * OutPut, void *p)
{
    float Increase;
    PID_t *PID = p;
    PID->CurrentValue = currentvalue;
    PID->err = PID->SetValue - PID->CurrentValue;
    Increase = PID->Kp * (PID->err - PID->errlast) + PID->Ki * PID->err + PID->Kd * (PID->err - 2 * PID->errlast + PID->errlastlast);
    PID->out = PID->outlast + Increase;

    PID->LeastValue = PID->CurrentValue;
    PID->errlast = PID->err;
    PID->errlastlast = PID->errlast;

    if (ABS(PID->out - PID->outlast) > PID->threshold)
    {
        if(PID->out > PID->outlast)
            PID->out = PID->outlast + PID->threshold;
        else
            PID->out = PID->outlast - PID->threshold;
    }

    if (PID->out >= PID->maximum)
        PID->out = PID->maximum;
    else if (PID->out <= PID->minimum)
        PID->out = PID->minimum;

    *OutPut = PID->out;
    PID->outlast = *OutPut;
}

void PID_Init(PID_t *PID, float Kp, float Ki, float Kd, float Kt, float SetValue, float threshold, float maximum, float minimum, _PID_FUNC *_PID_Count)
{
    PID->Kp = Kp;
    PID->Ki = Ki;
    PID->Kd = Kd;
    PID->SetValue = SetValue;
    PID->threshold = threshold;
    PID->maximum = maximum;
    PID->minimum = minimum;
    PID->LeastValue = 0;
    PID->err = PID->errlast = PID->errlastlast = 0;
    PID->integral = PID->out = PID->outlast = 0;
    PID->_PID_Count = _PID_Count;
}

